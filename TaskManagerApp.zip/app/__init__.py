
from flask import Flask, current_app
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager

db = SQLAlchemy()  # database
migrate = Migrate()  # migration fo database
crypt = Bcrypt()  # cryptography
jwt = JWTManager()


def create_app():
    app = Flask(__name__)

    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///project.db"
    app.config["SQLALCHEMY_ECHO"] = False
    db.init_app(app)

    migrate.init_app(app, db)
    crypt.init_app(app)
    jwt.init_app(app)
    app.config["JWT_SECRET_KEY"] = "LjOPrRLNxRmQ4VScX_GA8JElmy0z0fCZg1dG_ymXKG4"

    @jwt.user_identity_loader
    def uer_identity_lookup(user):
        return user

    from app.models import User

    @jwt.user_lookup_loader
    def user_lookup_callback(_jwt_header, jwt_data):
        identity = jwt_data["sub"]
        return User.query.filter_by(id=identity).first()

    from .auth import auth_bp
    from .todo import todo_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(todo_bp)
    return app
