
from flask_jwt_extended import create_access_token, jwt_required, get_current_user
from . import auth_bp as blp
from app import current_app, db, jwt
from .util import isEmail
from flask import request, jsonify
from sqlalchemy.exc import IntegrityError
from app.models import User


@blp.route("/register", methods=["POST"])
def register():
    try:
        name = request.form.get("full_name")
        email = request.form.get("email")
        password = request.form.get("password")

        if not isEmail(email):
            return jsonify(status=False, msg="Invalid email address")

        if not name.strip():
            return jsonify(status=False, msg="Empty name.")

        if not password.strip():
            return jsonify(status=False, msg="Empty password.")

        user = User(name=name, email=email, password=password)
        db.session.add(user)
        db.session.commit()
        return jsonify(status=True, msg="Successfully registered user!")
    except IntegrityError:
        return jsonify(status=False, msg="This email is already registered!")
    except Exception:
        return jsonify(status=False, msg="Something went wrong!")


@blp.route('/login', methods=["POST"])
def login():
    email = request.form.get('email').strip()
    password = request.form.get('password').strip()
    user = User.query.filter_by(email=email).first()
    if user and user.verify_password(password):
        token = create_access_token(identity=user.id, expires_delta=False)
        return jsonify(status=True, msg="Success Login!", access_token=token)
    return jsonify(status=False, msg="Invalid credentials!")
