
import re


def isEmail(s):
    reg_exp = re.compile(r"\w+\.*\w+@\w+.\w+")
    group = re.match(reg_exp, s)
    return bool(group) and group.group() == s.strip()
