
from app import current_app, db, crypt
import sqlalchemy as sa
from datetime import datetime

ACCEPTED_DAYS = (1, 2, 3, 4, 5, 6, 7)
NAMES = ("SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY")


class User(db.Model):
    __tablename__ = 'users'

    id = sa.Column(sa.Integer, primary_key=True, autoincrement=True)
    name = sa.Column(sa.String(255), nullable=False)
    email = sa.Column(sa.String(255), unique=True)
    password = sa.Column(sa.String(86), nullable=False)
    date_of_entry = sa.Column(sa.DateTime())

    def __init__(self, name, email, password):
        self.name = name
        self.email = email
        self.set_password(password)
        self.date_of_entry = datetime.now()

    def set_password(self, password):
        self.password = crypt.generate_password_hash(password)

    def verify_password(self, password):
        return crypt.check_password_hash(self.password, password)


class TodoTasks(db.Model):
    __tablename__ = 'todo_tasks'

    id = sa.Column(sa.Integer, primary_key=True, autoincrement=True)
    user_id = sa.Column(sa.Integer, db.ForeignKey("users.id"), nullable=False)
    task_title = sa.Column(sa.Text, nullable=False)
    task_description = sa.Column(sa.Text)
    date_of_creation = sa.Column(sa.DateTime, nullable=False)
    per_day = sa.Column(sa.Float, nullable=False)
    total_hours = sa.Column(sa.Float, nullable=False)
    start_from = sa.Column(sa.Integer, nullable=False)
    cannot_work_on = db.relationship("CannotWorkOn", backref="todo_task", cascade="all, delete-orphan", uselist=True)

    def __init__(self, user, title, description, per_day, total_hours, start_from=0):
        self.user_id = user.id
        self.task_title = title
        self.task_description = description
        self.date_of_creation = datetime.now()
        self.per_day = per_day
        self.total_hours = total_hours
        self.start_from = start_from if isinstance(start_from, int) else 0

    def __str__(self):
        out = "%s\n%s\nTotal Hours: %d\nPer Day: %d\n" % (self.task_title, self.task_description, self.total_hours, self.per_day)
        return out


class CannotWorkOn(db.Model):
    __tablename__ = "cannot_work_on"

    id = sa.Column(sa.Integer, primary_key=True, autoincrement=True)
    task_id = sa.Column(sa.Integer, db.ForeignKey("todo_tasks.id"), nullable=False)
    weekday = sa.Column(sa.Integer, nullable=False)
    start_time = sa.Column(sa.DateTime, nullable=False)
    end_time = sa.Column(sa.DateTime, nullable=False)
