
from flask import Blueprint

todo_bp = Blueprint("todo_bp", __name__, url_prefix="/todo")

from .routes import *
