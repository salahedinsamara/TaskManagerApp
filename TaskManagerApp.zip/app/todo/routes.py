
from datetime import timedelta, datetime
import calendar
from . import todo_bp as blp
from app import current_app, db
from flask import request, jsonify
from flask_jwt_extended import jwt_required, get_current_user
from app.models import *


@blp.route("/add_task", methods=["POST"])
@jwt_required()
def add_task():
    user = get_current_user()
    title = request.form.get("title")
    description = request.form.get("description")
    try:
        per_day = int(request.form.get("per_day"))
        total_hours = int(request.form.get("total_hours"))
        start_from = int(request.form.get("start_from", 0))
    except ValueError:
        return jsonify(status=False, msg="Invalid numeric values")

    task_to_do = TodoTasks(user, title, description, per_day, total_hours, start_from)
    db.session.add(task_to_do)
    db.session.commit()
    return jsonify(status=True, msg="Task added successfully")
