
from app import create_app

# calling the factory setup
app = create_app()
